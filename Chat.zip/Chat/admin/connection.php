<?php
$host="localhost";
$username="root";
$password="";
$database="chatty";

$conn=mysqli_connect($host, $username, $password, $database);
?>